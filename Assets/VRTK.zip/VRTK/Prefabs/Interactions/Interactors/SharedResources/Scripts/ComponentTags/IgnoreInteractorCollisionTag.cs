﻿namespace VRTK.Prefabs.Interactions.Interactors.ComponentTags
{
    using UnityEngine;

    public class IgnoreInteractorCollisionTag : MonoBehaviour
    {
    }
}
