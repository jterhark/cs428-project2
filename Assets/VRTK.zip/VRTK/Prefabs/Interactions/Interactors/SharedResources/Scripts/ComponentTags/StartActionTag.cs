﻿namespace VRTK.Prefabs.Interactions.Interactors.ComponentTags
{
    using UnityEngine;

    public class StartActionTag : MonoBehaviour
    {
    }
}
