﻿namespace VRTK.Prefabs.Interactions.Controllables.ComponentTags
{
    using UnityEngine;

    public class ControllableJointDriveContainerTag : MonoBehaviour { }
}
