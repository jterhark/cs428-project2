﻿namespace Test.Zinnia.Utility.Stub
{
    using UnityEngine;

    [AddComponentMenu("")]
    public class RuleStub : MonoBehaviour
    {
    }
}